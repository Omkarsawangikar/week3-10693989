package com.lti.eurekaConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;

import com.lti.eurekaConsumer.controller.CustomerController;


@SpringBootApplication
public class EurekaConsumerApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(EurekaConsumerApplication.class, args);
		CustomerController consumerController=ctx.getBean(CustomerController.class);
		System.out.println(consumerController);
		consumerController.getCustomer();
	}

}
